import React, { useEffect, useState } from "react";
import "./EditProfile.css"; // Nuevo archivo de estilos

const services = import.meta.env.VITE_SERVICE_API;

const API_URL = `${services}/employees`;

export default function EditProfile({ employeeId }) {
  const [form, setForm] = useState({
    username: "",
    full_name: "",
    //email: "",
    roles:"",
    password: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`${API_URL}/${employeeId}`);
        if (!res.ok) throw new Error("Error cargando perfil");
        const data = await res.json();
        //(data,"clog data")
        setForm({
          username: data.username || "",
          full_name: data.full_name || "",
          //email: data.email || "",
          roles:data.role_ids || "",
          password: "",
        });
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [employeeId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setError(null);
    setSuccessMsg(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.username.trim()) {
      setError("El username es obligatorio");
      return;
    }
    if (!form.full_name.trim()) {
      setError("El nombre completo es obligatorio");
      return;
    }

    setLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const payload = { username: form.username, full_name: form.full_name, edit: true, roles:form.roles };
      if (form.password.trim() !== "") payload.password = form.password;
      //console.log("puesto",form.roles)

      const res = await fetch(`${API_URL}/${employeeId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.message || "Error actualizando perfil");
      }

      setSuccessMsg(`¡Perfil actualizado con éxito!`);
      setForm((f) => ({ ...f, password: "" }));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="edit-profile-container">
      <h2>Editar Perfil</h2>

      {loading && <p className="info-msg">Cargando...</p>}
      {error && <p className="error-msg">{error}</p>}
      {successMsg && <p className="success-msg"><strong>{successMsg} </strong><br />Los cambios se aplicarán en tu próximo inicio de sesión.</p>}

      <form onSubmit={handleSubmit} className="edit-profile-form">
        <div className="form-group">
          <label htmlFor="username">Username:</label>
          <input
            id="username"
            name="username"
            value={form.username}
            onChange={handleChange}
            disabled
          />
        </div>

        <div className="form-group">
          <label htmlFor="full_name">Nombre completo:</label>
          <input
            id="full_name"
            name="full_name"
            value={form.full_name}
            onChange={handleChange}
            disabled={loading}
          />
        </div>

        {/* <div className="form-group" style={{ display: "none" }}>
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" name="email" value={form.email} onChange={handleChange} />
        </div> */}

        <div className="form-group">
          <label htmlFor="password">Nueva contraseña (opcional):</label>
          <input
            type="password"
            id="password"
            name="password"
            value={form.password}
            onChange={handleChange}
            disabled={loading}
            placeholder="Dejar en blanco para no cambiar"
          />
        </div>

        {!successMsg && (
          <button type="submit" disabled={loading} className="submit-btn">
            Guardar Cambios
          </button>
        )}
      </form>
    </div>
  );
}
